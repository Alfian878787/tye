require 'etcd'

class Etcd::Client
  include Etcd::Health
end
