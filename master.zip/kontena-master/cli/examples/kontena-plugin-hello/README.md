# Kontena Hello World Plugin

Just an example how to write Kontena cli plugins.
