module Kontena
  module Plugin
    module Hello
      VERSION = '0.1.0'
    end
  end
end
